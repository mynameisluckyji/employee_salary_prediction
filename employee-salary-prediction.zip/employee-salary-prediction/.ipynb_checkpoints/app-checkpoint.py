import streamlit as st
import pandas as pd
import numpy as np
import joblib

model = joblib.load("salary_model.pkl")
encoders = joblib.load("encoders.pkl")

st.title("Employee Salary Prediction App")
st.write("Enter the details below to predict salary class")

def user_input():
    age = st.number_input("Age", 17, 90, 30)
    workclass = st.selectbox("Workclass", encoders['workclass'].classes_)
    fnlwgt = st.number_input("Final Weight", 10000, 1000000, 200000)
    education = st.selectbox("Education", encoders['education'].classes_)
    education_num = st.slider("Education Number", 1, 16, 10)
    marital_status = st.selectbox("Marital Status", encoders['marital-status'].classes_)
    occupation = st.selectbox("Occupation", encoders['occupation'].classes_)
    relationship = st.selectbox("Relationship", encoders['relationship'].classes_)
    race = st.selectbox("Race", encoders['race'].classes_)
    sex = st.selectbox("Sex", encoders['sex'].classes_)
    capital_gain = st.number_input("Capital Gain", 0, 100000, 0)
    capital_loss = st.number_input("Capital Loss", 0, 100000, 0)
    hours_per_week = st.slider("Hours per Week", 1, 100, 40)
    native_country = st.selectbox("Native Country", encoders['native-country'].classes_)

    data = {
        'age': age,
        'workclass': encoders['workclass'].transform([workclass])[0],
        'fnlwgt': fnlwgt,
        'education': encoders['education'].transform([education])[0],
        'education-num': education_num,
        'marital-status': encoders['marital-status'].transform([marital_status])[0],
        'occupation': encoders['occupation'].transform([occupation])[0],
        'relationship': encoders['relationship'].transform([relationship])[0],
        'race': encoders['race'].transform([race])[0],
        'sex': encoders['sex'].transform([sex])[0],
        'capital-gain': capital_gain,
        'capital-loss': capital_loss,
        'hours-per-week': hours_per_week,
        'native-country': encoders['native-country'].transform([native_country])[0],
    }
    return pd.DataFrame([data])

input_df = user_input()
if st.button("Predict"):
    prediction = model.predict(input_df)
    result = encoders['salary'].inverse_transform(prediction)[0]
    st.success(f"The predicted salary class is: {result}")
