import streamlit as st
import pandas as pd
import numpy as np
import joblib
import shap
import matplotlib.pyplot as plt

# Load model and preprocessors
model = joblib.load("salary_model.pkl")
scaler = joblib.load("scaler.pkl")
encoders = joblib.load("encoders.pkl")

st.set_page_config(
    page_title="💼 Employee Salary Prediction",
    page_icon="💼",
    layout="wide",
)

# Custom CSS for futuristic look
st.markdown(
    """
    <style>
    body {
        background-color: #0E1117;
        color: #FAFAFA;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .stButton>button {
        background: linear-gradient(90deg, #4CAF50, #81C784);
        color: white;
        font-weight: bold;
        border-radius: 10px;
        padding: 10px;
    }
    .stButton>button:hover {
        background: linear-gradient(90deg, #388E3C, #4CAF50);
        color: white;
    }
    .title {
        font-size: 3rem;
        text-align: center;
        margin-bottom: 20px;
        font-weight: 700;
        color: #81C784;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown('<div class="title">💼 Employee Salary Prediction App</div>', unsafe_allow_html=True)

with st.sidebar:
    st.image("https://cdn-icons-png.flaticon.com/512/3135/3135715.png", width=150)
    st.header("Input Employee Details")
    
    age = st.slider("Age", 18, 90, 30)
    workclass = st.selectbox("Workclass", encoders['workclass'].classes_)
    education = st.selectbox("Education", encoders['education'].classes_)
    occupation = st.selectbox("Occupation", encoders['occupation'].classes_)
    hours_per_week = st.slider("Hours per week", 1, 99, 40)
    sex = st.selectbox("Gender", encoders['sex'].classes_)
    native_country = st.selectbox("Native Country", encoders['native-country'].classes_)
    capital_gain = st.number_input("Capital Gain", min_value=0, max_value=100000, value=0)
    capital_loss = st.number_input("Capital Loss", min_value=0, max_value=100000, value=0)

def encode_value(val, col):
    """Encode input value using stored LabelEncoder."""
    return int(encoders[col].transform([val])[0])

def prepare_input():
    data_dict = {
        "age": age,
        "workclass": encode_value(workclass, 'workclass'),
        "fnlwgt": 200000,  # dummy fixed value (you can add input if needed)
        "education": encode_value(education, 'education'),
        "education-num": 13,  # dummy fixed value (you can extend)
        "marital-status": 1,  # dummy fixed value (extend as needed)
        "occupation": encode_value(occupation, 'occupation'),
        "relationship": 1,  # dummy fixed value
        "race": 4,  # dummy fixed value
        "sex": encode_value(sex, 'sex'),
        "capital-gain": capital_gain,
        "capital-loss": capital_loss,
        "hours-per-week": hours_per_week,
        "native-country": encode_value(native_country, 'native-country'),
    }
    return pd.DataFrame([data_dict])

input_df = prepare_input()

# Scale input
input_scaled = scaler.transform(input_df)

if st.button("Predict Salary"):
    prediction = model.predict(input_scaled)[0]
    proba = model.predict_proba(input_scaled)[0][prediction]

    st.markdown(f"### Prediction: {'💰 >50K' if prediction == 1 else '💸 <=50K'}")
    st.markdown(f"### Confidence: {proba*100:.2f}%")

    # SHAP Explanation (optional)
    try:
        explainer = shap.Explainer(model.predict, input_scaled)
        shap_values = explainer(input_scaled)

        st.subheader("Feature Impact on Prediction")
        shap.initjs()
        shap.plots.bar(shap_values, max_display=10)
        st.pyplot(bbox_inches='tight')
    except Exception as e:
        st.write("SHAP explainability currently not available.")

st.markdown("---")
st.markdown("Created with ❤️ by You")


